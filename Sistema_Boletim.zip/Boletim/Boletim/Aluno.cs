﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boletim
{
    public class Aluno
    {
        public string nome { get; set; }
        public string sobreNome { get; set; }
        public DateTime dataNascimento { get; set; }
        public string cpf { get; set; }
        public string curso { get; set; }
    }
}


