﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Boletim
{
    public class CadastroAluno
    {
        public static void Cadastro()
        {
            Aluno objAluno = new Aluno();
            int opcao = 0;

            objAluno = CadastroAluno.InserirInformacoes();

            opcao = Convert.ToInt32(Console.ReadLine());

            switch (opcao)
            {
                case 01:
                    CadastroAluno.Voltar();
                    break;
                case 02:
                    CadastroAluno.Salvar(objAluno);
                    break;
                case 03:
                    CadastroAluno.Excluir();
                    break;
            }

            Console.ReadKey();

        }

        public static Aluno InserirInformacoes()
        {
            Aluno objAluno = new Aluno();

            Console.WriteLine("Universidade do Sitio do Caqui");
            Console.WriteLine("--------------------------------------------------------------");
            Console.WriteLine("");

            Console.WriteLine("Cadastro de Aluno");
            Console.WriteLine("--------------------------------------------------------------");
            Console.WriteLine("");

            Console.Write("Nome: ");
            objAluno.nome = Console.ReadLine();

            Console.Write("Sobrenome: ");
            objAluno.sobreNome = Console.ReadLine();

            Console.Write("Data de Nascimento: ");
            objAluno.dataNascimento = Convert.ToDateTime(Console.ReadLine());

            Console.Write("CPF: ");
            objAluno.cpf = Console.ReadLine();

            Console.Write("Curso: ");
            objAluno.curso = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("--------------------------------------------------------------");
            Console.WriteLine("01 - Voltar | 02 - Salvar | 03 - Excliuir ");

            return objAluno;


        }

        public static void Voltar()
        {
            Console.Clear();
            CadastroAluno.InserirInformacoes();
        }

        public static void Salvar(Aluno objAluno)
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/CadastroAluno.txt";

            if (!File.Exists(path))
            {
                try
                {
                    if (ValidarInformacoesObrigatorias(objAluno) && ValidarInformacoesTipo(objAluno))
                    {
                        using (StreamWriter sw = File.CreateText(path))
                        {
                            sw.WriteLine("---------------------------------------------------");
                            sw.WriteLine("Nome: " + objAluno.nome);
                            sw.WriteLine("Sobrenome: " + objAluno.sobreNome);
                            sw.WriteLine("Data Nascimento: " + objAluno.dataNascimento.ToString("dd/MM/yyyy"));
                            sw.WriteLine("CPF: " + objAluno.cpf);
                            sw.WriteLine("Curso " + objAluno.curso);

                            sw.Close();

                            Console.WriteLine("");
                            Console.WriteLine("Salvo com Sucesso. ");
                        }
                    }
                    else
                        Console.WriteLine("Campos inválidos");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            else
                Console.WriteLine("Arquivo existente.");
        }

        public static void Excluir()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/CadastroAluno.txt";

            if (File.Exists(path))
            {
                try
                {
                    File.Delete(path);

                    Console.WriteLine("");
                    Console.WriteLine("Arquivo excluido.");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            else
            {
                Console.WriteLine("Arquivo não existe.");
            }
        }

        public static bool ValidarInformacoesObrigatorias(Aluno objAluno)
        {
            if (string.IsNullOrEmpty(objAluno.nome) || string.IsNullOrEmpty(objAluno.sobreNome) || objAluno.dataNascimento == null || string.IsNullOrEmpty(objAluno.cpf) || string.IsNullOrEmpty(objAluno.curso))
                return false;

            return true;
        }

        public static bool ValidarInformacoesTipo(Aluno objAluno)
        {
            decimal cpf;
            DateTime dataNascimento = new DateTime(2002, 01, 01);
            string nome = string.Empty;

            if (!decimal.TryParse(objAluno.cpf, out cpf))
            {
                Console.WriteLine("CPF pode ser preenchido apemas por números.");

                return false;
            }

            if (objAluno.dataNascimento > dataNascimento)
            {
                Console.WriteLine("Data de Nascimento não pode ser maior que " + dataNascimento.ToString("dd/MM/yyyy"));

                return false;
            }

            Regex r = new Regex(@"\d");
            if (r.Match(objAluno.nome).Success)
            {
                Console.WriteLine("Campo pode ser preenchido apenas por letras.");

                return false;
            }


            return true;
        }

        public static List<string> LerCadastroAluno()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/CadastroAluno.txt";
            List<string> listaCadastroAluno = new List<string>();
            string texto;

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((texto = sr.ReadLine()) != null)
                    {
                        listaCadastroAluno.Add(texto);
                    }

                    foreach (var linha in listaCadastroAluno)
                        Console.WriteLine(linha);

                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaCadastroAluno;
        }
    }

}
