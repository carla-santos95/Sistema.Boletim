﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boletim
{
    public class Notas
    {
        public Double Nota { get; set; }
        public Aluno aluno { get; set; }
        public Materia materia { get; set; }
    }
}
