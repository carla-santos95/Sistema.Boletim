﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boletim
{
    public class MenuPrincipal
    {
        public static void Main(string[] args)
        {
            int opcao = 0;

            Console.WriteLine("Universidade Ecológica do Sitio do Caqui");
            Console.WriteLine("----------------------------------------------------------------------");
            Console.WriteLine("");

            Console.WriteLine("Boletim Eletronico");

            Console.WriteLine("");
            Console.WriteLine("----------------------------------------------------------------------");

            Console.WriteLine(" 01 - Cadastro Aluno | 02 - Cadastro Matéria | 03 - Cadastro Nota | 04 - Visualizar Informações do Aluno");
            opcao = Convert.ToInt32(Console.ReadLine());

            switch (opcao)
            {
                case 01:
                    CadastroAluno.Cadastro();
                    break;
                case 02:
                    CadastroMateria.Cadastro();
                    break;
                case 03:
                    CadastroNotas.Cadastro();
                    break;
                case 04:
                    CadastroNotas.VisualizarNotasAluno();
                    break;
            }
        }
    }
}
