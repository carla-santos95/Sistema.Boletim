﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boletim
{
    public class Materia
    {
        public string descricao { get; set; }
        public DateTime dataCadastro { get; set; }
        public string situacao { get; set; }
    }
}
