﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace Boletim
{
    public class CadastroMateria
    {

        public static void Cadastro()
        {
            Materia objMateria = new Materia();
            int opcao = 0;

            objMateria = CadastroMateria.InseriInformacoes();

            opcao = Convert.ToInt32(Console.ReadLine());

            switch (opcao)
            {
                case 01:
                    CadastroMateria.Voltar();
                    break;
                case 02:
                    CadastroMateria.Salvar(objMateria);
                    break;
                case 03:
                    CadastroMateria.Excluir();
                    break;
            }

            Console.ReadKey();
        }


        public static Materia InseriInformacoes()
        {
            Materia objMateria = new Materia();

            Console.WriteLine("Universidade Ecológica do Sítio do Caqui");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("");

            Console.WriteLine("Cadastro de Matéria");

            Console.WriteLine("");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("");

            Console.Write("Descrição: ");
            objMateria.descricao = Console.ReadLine();

            Console.Write("Data Cadastro: ");
            objMateria.dataCadastro = Convert.ToDateTime(Console.ReadLine());

            Console.Write("Situação: ");
            objMateria.situacao = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("--------------------------------------------------------------");
            Console.WriteLine("01 - Voltar | 02 - Salvar | 03 - Excliuir ");

            return objMateria;

        }

        public static void Voltar()
        {
            Console.Clear();
            CadastroMateria.InseriInformacoes();
        }


        public static void Salvar(Materia objMateria)
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/CadastroMateria.txt";

            if (!File.Exists(path))
            {
                try
                {
                    if (ValidarInformacoesObrigatorias(objMateria) && ValidarInformacoesTipos(objMateria))
                    {
                        using (StreamWriter sw = File.CreateText(path))
                        {
                            sw.WriteLine("---------------------------------------------------");
                            sw.WriteLine("Descrição: " + objMateria.descricao);
                            sw.WriteLine("Data Cadastro: " + objMateria.dataCadastro.ToString("dd/MM/yyyy"));
                            sw.WriteLine("Situação: " + objMateria.situacao);

                            sw.Close();

                            Console.WriteLine("");
                            Console.WriteLine("Salvo com sucesso");
                        }
                    }
                    else
                        Console.WriteLine("Campos inválidos");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            else
                Console.WriteLine("Arquivo existe");
        }


        public static void Excluir()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/CadastroMateria.txt";

            if (File.Exists(path))
            {
                try
                {
                    File.Delete(path);

                    Console.WriteLine("");
                    Console.WriteLine("Arquivo excluido");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            else
            {
                Console.WriteLine("Arquivo não existe");
            }
        }

        public static bool ValidarInformacoesObrigatorias(Materia objMateria)
        {
            if (string.IsNullOrEmpty(objMateria.descricao) || objMateria.dataCadastro == null || objMateria.situacao == null )
                return false;

            return true;
        }

        public static bool ValidarInformacoesTipos(Materia objMateria)
        {
            string descricao = string.Empty;
            DateTime dataCadastro = DateTime.Now;
            string situacao = string.Empty;

            Regex r = new Regex(@"\d");
            if (r.Match(objMateria.descricao).Success)
            {
                Console.WriteLine("Descrição só pode ser preenchido por letras");

                return false;
            }

            if (objMateria.dataCadastro > dataCadastro)
            {
                Console.WriteLine("Data do cadastro não poder maior que " + dataCadastro.ToString("dd/MM/yyyy"));

                return false;
            }

            return true;

        }

        public static void LerCadastroMataeria()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/Boletim.txt";
            List<string> lsCadastroAluno = new List<string>();
            string texto;

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((texto = sr.ReadLine()) != null)
                    {
                        lsCadastroAluno.Add(texto);
                    }

                    foreach (var linha in lsCadastroAluno)
                        Console.WriteLine(linha);

                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

    }

}

    