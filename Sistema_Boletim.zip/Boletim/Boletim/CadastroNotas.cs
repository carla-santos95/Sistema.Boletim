﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
namespace Boletim
{

    public class CadastroNotas
    {
        public static void Cadastro()
        {
            Notas objNotas = new Notas();
            int opcao = 0;

            objNotas = CadastroNotas.InseriInformacoes();

            opcao = Convert.ToInt32(Console.ReadLine());

            switch (opcao)
            {
                case 01:
                    CadastroNotas.Voltar();
                    break;
                case 02:
                    CadastroNotas.Salvar(objNotas);
                    break;
                case 03:
                    CadastroNotas.Excluir();
                    break;
            }

            Console.ReadKey();

        }

        public static Notas InseriInformacoes()
        {
            Notas objNotas = new Notas();
            objNotas.aluno = new Aluno();
            objNotas.materia = new Materia();

            Console.WriteLine("Universidade Ecológica do Sítio do Caqui");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("");

            Console.WriteLine("Cadastro de Notas");

            Console.WriteLine("");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("");

            objNotas.aluno.nome = LerCadastroAluno()[1].Replace("Nome:", "");
            objNotas.aluno.sobreNome = LerCadastroAluno()[2].Replace("Sobrenome:", "");

            Console.WriteLine("Aluno: " + objNotas.aluno.nome + objNotas.aluno.sobreNome);

            objNotas.materia.descricao = LerCadastroMateria()[1].Replace("Descrição:", "");
            Console.WriteLine("Matéria: " + objNotas.materia.descricao);

            Console.Write("Nota: ");
            objNotas.Nota = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("");
            Console.WriteLine("----------------------------------------");
            Console.WriteLine("01 - Voltar  |  02 - Salvar  |  03 - Excluir");

            return objNotas;
        }

        public static void Voltar()
        {
            Console.Clear();
            CadastroNotas.InseriInformacoes();
        }

        public static void Salvar(Notas objNotas)
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/Boletim.txt";

            if (!File.Exists(path))
            {
                try
                {
                    if (ValidarInformacoesObrigatorias(objNotas))
                    {
                        using (StreamWriter sw = File.CreateText(path))
                        {
                            sw.WriteLine("---------------------------------------");
                            sw.WriteLine("Aluno: " + objNotas.aluno.nome + objNotas.aluno.sobreNome);
                            sw.WriteLine("Matéria: " + objNotas.materia.descricao);
                            sw.WriteLine("Nota: " + objNotas.Nota);

                            sw.Close();

                            Console.WriteLine("");
                            Console.WriteLine("Salvo com sucesso");
                        }
                    }
                    else
                        Console.WriteLine("Campos inválidos");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            else
                Console.WriteLine("Arquivo existente");
        }

        public static void Excluir()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/Boletim.txt";

            if (File.Exists(path))
            {
                try
                {
                    File.Delete(path);

                    Console.WriteLine("");
                    Console.WriteLine("Excluido");
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }
            else
            {
                Console.WriteLine("Arquivo não existe");
            }
        }

        public static bool ValidarInformacoesObrigatorias(Notas objNotas)
        {
            if (string.IsNullOrEmpty(objNotas.aluno.nome) || string.IsNullOrEmpty(objNotas.materia.descricao) || (Convert.ToDecimal(objNotas.Nota) < 0 || objNotas.Nota > 100))
                return false;

            return true;
        }

        public static void LeituraCadastroNotas()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/Boletim.txt";
            List<string> lsCadastroNotas = new List<string>();
            string texto;

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((texto = sr.ReadLine()) != null)
                    {
                        lsCadastroNotas.Add(texto);
                    }

                    foreach (var linha in lsCadastroNotas)
                        Console.WriteLine(linha);

                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public static List<string> LerCadastroAluno()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/CadastroAluno.txt";
            List<string> listaCadastroAluno = new List<string>();
            string texto;

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((texto = sr.ReadLine()) != null)
                    {
                        listaCadastroAluno.Add(texto);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaCadastroAluno;
        }

        public static List<string> LerCadastroMateria()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/CadastroMateria.txt";
            List<string> lsCadastroAluno = new List<string>();
            string texto;

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((texto = sr.ReadLine()) != null)
                    {
                        lsCadastroAluno.Add(texto);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return lsCadastroAluno;
        }

        public static void VisualizarNotasAluno()
        {
            string path = "C:/Users/Carla Santos/Documents/Boletim/Boletim.txt";
            List<string> lsNotasAluno = new List<string>();
            string texto;

            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((texto = sr.ReadLine()) != null)
                    {
                        lsNotasAluno.Add(texto);
                    }

                    foreach (var linha in lsNotasAluno)
                        Console.WriteLine(linha);

                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
